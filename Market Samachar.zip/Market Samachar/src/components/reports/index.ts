export { WeeklyReportCard } from './WeeklyReportCard';
